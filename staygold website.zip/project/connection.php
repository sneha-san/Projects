<?php
$conn=mysqli_connect("localhost","root","","staygold");
if(!$conn){
echo "NOt connected";
}
?>